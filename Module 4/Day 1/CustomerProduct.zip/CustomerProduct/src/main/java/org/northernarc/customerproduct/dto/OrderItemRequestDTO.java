package org.northernarc.customerproduct.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderItemRequestDTO {

    @Positive
    @Min(1)
    @NotNull
    private Integer quantity;

    @NotNull
    private Integer orderId;

    @NotNull
    private Integer productId;
}
