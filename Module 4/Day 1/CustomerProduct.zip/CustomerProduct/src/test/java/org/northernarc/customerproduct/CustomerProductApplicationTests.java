package org.northernarc.customerproduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerProductApplicationTests {

    @Test
    void contextLoads() {
    }

}
